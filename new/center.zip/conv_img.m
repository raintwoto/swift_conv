c=dir('*.jpg');
for i=2;%:1%numel(c)
    mkdir(c(i).name(1:end-4));
    imFinal=imread(c(i).name);
    imStart=randn(size(imFinal));
    imSeq=minPhaseInterp(imStart,imFinal,[linspace(0,0.5,50)]);
%     figure;
    colormap gray;
    for iSeq=1:50,
        pic=((imSeq(:,:,iSeq)-min(min(imSeq(:,:,iSeq))))./(max(max(imSeq(:,:,iSeq))-min(min(imSeq(:,:,iSeq))))));
        PSF = fspecial('gaussian',60,10);
pic = edgetaper(pic,PSF);
        imwrite(pic,[c(i).name(1:end-4),'/',num2str(iSeq),'.jpg']);        
    end
end